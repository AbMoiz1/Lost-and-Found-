"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.signToken = signToken;
exports.verifyToken = verifyToken;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const secret = () => {
    const s = process.env.JWT_SECRET;
    if (!s)
        throw new Error('JWT_SECRET is not set');
    return s;
};
const expiry = () => process.env.JWT_EXPIRY ?? '1h';
function signToken(payload) {
    return jsonwebtoken_1.default.sign(payload, secret(), { expiresIn: expiry() });
}
function verifyToken(token) {
    return jsonwebtoken_1.default.verify(token, secret());
}
//# sourceMappingURL=jwt.js.map