"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("./app"));
const migrate_1 = require("./migrate");
const PORT = Number(process.env.PORT ?? 4001);
async function main() {
    await (0, migrate_1.runMigrations)();
    app_1.default.listen(PORT, () => {
        console.log(`Auth service listening on port ${PORT}`);
    });
}
main().catch((err) => {
    console.error('Failed to start auth service:', err);
    process.exit(1);
});
//# sourceMappingURL=index.js.map